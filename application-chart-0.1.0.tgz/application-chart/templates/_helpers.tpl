{{/*
Expand the name of the chart.
*/}}
{{- define "application-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name. By default uses release name.
*/}}
{{- define "application-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "application-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels merged with optional commonLabels.
*/}}
{{- define "application-chart.labels" -}}
helm.sh/chart: {{ include "application-chart.chart" . }}
{{ include "application-chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels (used by deployment, service, etc.)
*/}}
{{- define "application-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "application-chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "application-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "application-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Container port (from values.port).
*/}}
{{- define "application-chart.port" -}}
{{- .Values.port | int }}
{{- end }}

{{/*
Service port (from values.service.port or values.port).
*/}}
{{- define "application-chart.servicePort" -}}
{{- default .Values.port .Values.service.port | int }}
{{- end }}

{{/*
Service targetPort (defaults to container port).
*/}}
{{- define "application-chart.serviceTargetPort" -}}
{{- if kindIs "invalid" .Values.service.targetPort -}}
{{- include "application-chart.port" . }}
{{- else -}}
{{- .Values.service.targetPort | int }}
{{- end }}
{{- end }}
